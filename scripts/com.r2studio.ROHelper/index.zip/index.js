var DEBUG_LEVEL = 0;
var DEFAULT_QUALITY = 1080;

/**
 * Global function
 */
function DEBUG() {
	if (typeof arguments[0] !== 'number') {
		throw 'DEBUG funciont error';
	}
	if (arguments[0] <= this.DEBUG_LEVEL) {
		console.log.apply(undefined, Array.prototype.slice.call(arguments, 1));
	}
}

function getScriptPath() {
	return getStoragePath() + '/scripts/com.r2studio.ROHelper/';
}

/**
 * Bot
 */
function Bot() {
}

Bot.prototype.getScreenRatio = function() {
	var screen = getScreenSize();
	this.ratio = screen.height / DEFAULT_QUALITY;

	DEBUG(0, 'Screen: width[', screen.width, '] height[', screen.height, '] Ratio: [', this.ratio, ']');
}

Bot.prototype.init = function(settings) {
	var FILES = ['fishingTask'];
	var path = getScriptPath() + 'js/';

	for (var index = 0; index < FILES.length; index++) {
		var filePath = path + FILES[index] + '.js';
		var f = readFile(filePath);
		if (f == undefined || f.length == 0){
			throw 'Load file [' + filePath + '] failed';
		}
		runScript(f);
	}

	// debug log setting
	if (settings.debugLog && settings.debugLog === 'on') {
		DEBUG_LEVEL = 1;
	} else {
		DEBUG_LEVEL = 0;
	}

	// get screen ratio
	this.getScreenRatio();

	switch(settings.task) {
		case "fishingTask":
			this.currentTask = new FishingTask({
				ratio: this.ratio,
				stopWhenNormalBait: true,
				fishingTimes: settings.fishingTimes
			});
			break;
		default:
			throw "Unknown task [" + settings.task.value + "]";
	}


	DEBUG(1, 'Succeed to initialize Bot.');
}

function startBot(settings) {
	this.bot = new Bot();
	DEBUG(0, "Start Bot");

	try {
		this.bot.init(settings);
	} catch (msg) {
		DEBUG(0, 'Failed to init bot: ', msg);
		return;
	}

	this.bot.currentTask.startTask();
}

function stopBot() {
	DEBUG(0, "Stop Bot");

	if (this.bot.currentTask && this.bot.currentTask.stopTask) {
		this.bot.currentTask.stopTask();
	}
}

DEBUG(0, "<<>>");

startBot({
	task: "fishingTask",
	debugLog: "on"
});